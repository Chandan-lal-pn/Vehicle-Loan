
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerInfo } from '../CustomerInfo';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-loginnew',
  templateUrl: './loginnew.component.html',
  styleUrls: ['./loginnew.component.css']
})
export class LoginnewComponent implements OnInit {
  custInfo = new CustomerInfo() ;
  msg = "";
  isLogin = "false";
  constructor(private service:LoginService, private route :Router) { }
  firstName :any = localStorage.getItem("userInfo");

  ngOnInit(): void {
  }
  getCustInfo(){
    this.service.logInUserFromRemote(this.custInfo).subscribe(
      data => {
        console.log("Responce received");
        console.log("Hello" + this.firstName)
        this.custInfo = data;
        console.log(this.custInfo);
        sessionStorage.setItem("userdata", JSON.stringify(this.custInfo));
        sessionStorage.setItem("userName", this.custInfo.firstName);
        this.isLogin = "true";
        sessionStorage.setItem("isLogin", this.isLogin);
        this.route.navigate(['/userHome']);
      },
      error => {
        console.log("Exception Occured");
        sessionStorage.setItem("isLogin", this.isLogin);
        this.msg ="Bad Credentials, please enter valid mobile number and password"
      }
      

    )
  }

}
