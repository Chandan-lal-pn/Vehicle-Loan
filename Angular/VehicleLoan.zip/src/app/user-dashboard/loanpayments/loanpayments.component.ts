import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/PojoNgClasses/customer'; 
import { LoanPayments } from 'src/app/PojoNgClasses/loan-payments'; 
import { LoanPayServiceService } from 'src/app/services/loan-pay-service.service';

@Component({
  selector: 'app-loanpayments',
  templateUrl: './loanpayments.component.html',
  styleUrls: ['./loanpayments.component.css'],
})
export class LoanpaymentsComponent implements OnInit {
  
  loanPayList: LoanPayments[] = [];

  newCust: Customer = JSON.parse(sessionStorage.getItem("userdata"));

  constructor(private loanpayserve: LoanPayServiceService, private route: Router) {
    //this.id = this.Activatedroute.snapshot.paramMap.get('id');
  }

  ngOnInit(): void {
    
    this.onSearch();
    
  }
  onSearch() {
    console.log(this.newCust);
    this.loanpayserve
      .getLoanByCustId(this.newCust.custId)
      .subscribe(data => {
        this.loanPayList = data;

      },
        error => console.log("eeee")
      );
  }

  payEmiForLoan(loanId: any) {
    sessionStorage.setItem("loanID", loanId);
    this.route.navigate(['/payEmi']);
  }
  viewEmiForLoan(loanId: any) {
    sessionStorage.setItem("loanID", loanId);
    this.route.navigate(['/viewEmis']);
  }

}
