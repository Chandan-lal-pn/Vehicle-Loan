import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../PojoNgClasses/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private myhttp: HttpClient) { }

  private baseURL = "http://localhost:8088/cust/";
  public getCustomerList(custId: number): Observable<any> {
    return this.myhttp.get<any>("http://localhost:8088/cust/getCustById/" + custId);

  }

  registerNewCustomer(customer: Customer): Observable<any>{
    console.log('reg service'+customer.firstName);
    return this.myhttp.post<any>(this.baseURL + "regisCust" , customer);
  }

  updateCustDet(customer:Customer):Observable<string>{
    console.log('update service'+customer.firstName);
    return this.myhttp.post<string>(this.baseURL+ "addCustAppForm2" , customer);
}
}
