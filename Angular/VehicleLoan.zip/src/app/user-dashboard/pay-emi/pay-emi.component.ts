import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Emi } from 'src/app/PojoNgClasses/emi'; 
import { LoanPayments } from 'src/app/PojoNgClasses/loan-payments'; 
import { EmiService } from '../../services/emi-service.service';
import { LoanPayServiceService } from '../../services/loan-pay-service.service';

@Component({
  selector: 'app-pay-emi',
  templateUrl: './pay-emi.component.html',
  styleUrls: ['./pay-emi.component.css'],
})
export class PayEmiComponent implements OnInit {
  constructor(
    private emiServe: EmiService,
    private loanServe: LoanPayServiceService,
    private route: Router
  ) { }
  newEmi: Emi = new Emi();
  emiId: any;
  loanPaymentId: number = JSON.parse(sessionStorage.getItem('loanID')); //static
  ngOnInit(): void { }

  onClickPay() {
    console.log('componentTS' + this.newEmi.transactionAmount);
    this.emiServe.emiPay(this.newEmi, this.loanPaymentId).subscribe(
      (data) => {
        console.log('successful' + data);
        this.loanServe
          .updateLoanEntryOnEmiPay(data, this.loanPaymentId)
          .subscribe(
            (data) => {
              console.log('loan updated' + data);
            },
            (error) => {
              console.log('error occured');
            }
          );

      },
      (error) => {
        console.log('error occured');
      }
    );
    
    this.route.navigate['/viewEmis'];
  }
}
