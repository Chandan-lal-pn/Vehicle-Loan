import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-for-loan',
  templateUrl: './apply-for-loan.component.html',
  styleUrls: ['./apply-for-loan.component.css']
})
export class ApplyForLoanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
