import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoanPayServiceService {

  baseURL: string = "http://localhost:8088/loanPayments/";
  constructor(private myhttp: HttpClient) { }

  updateLoanEntryOnEmiPay(emiId: number, loanId: number): Observable<any> {
    console.log('loan service');
    return this.myhttp.post<any>(this.baseURL + 'updateLoan/' + loanId + '/' + emiId,null);
  }
  getLoanByCustId(custId: number): Observable<any> {
    console.log('loan service');
    return this.myhttp.get<any>(this.baseURL + 'getLoanPayByCustId/' + custId);
  }
  newLoanEntry(appId: number, adminId: number): Observable<any> {
    console.log('loan service');
    return this.myhttp.post<any>(this.baseURL + 'newLoan/' + appId + '/' + adminId, null);
  }

}
