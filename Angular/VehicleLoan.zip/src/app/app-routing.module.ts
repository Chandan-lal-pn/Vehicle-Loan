import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminhomeComponent } from './admindashboard/adminhome/adminhome.component';
import { ApplicationApprovalComponent } from './admindashboard/application-approval/application-approval.component';
import { EmitransactionComponent } from './admindashboard/emitransaction/emitransaction.component';
import { EnterLoanComponent } from './admindashboard/enter-loan/enter-loan.component';
import { EnterVehicleComponent } from './admindashboard/enter-vehicle/enter-vehicle.component';
import { LoanPayDetComponent } from './admindashboard/loan-pay-det/loan-pay-det.component';
import { ViewCustomerComponent } from './admindashboard/view-customer/view-customer.component';
import { ViewLoanComponent } from './admindashboard/view-loan/view-loan.component';
import { ViewVehicleComponent } from './admindashboard/view-vehicle/view-vehicle.component';
import { AfternavComponent } from './afternav/afternav.component';
import { ApplyForLoanComponent } from './apply-for-loan/apply-for-loan.component';
import { CheckeligibilityComponent } from './checkeligibility/checkeligibility.component';
import { CustomerinfoComponent } from './customerinfo/customerinfo.component';
import { EMIComponent } from './emi/emi.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { FinalApplicationComponent } from './final-application/final-application.component';
import { Form1Component } from './form1/form1.component';
import { Form2Component } from './form2/form2.component';
import { Form3Component } from './form3/form3.component';
import { Form4Component } from './form4/form4.component';
import { HomeComponent } from './home/home.component';
import { LoginnewComponent } from './loginnew/loginnew.component';
import { RegisterComponent } from './register/register.component';
import { ApplicationDetComponent } from './user-dashboard/application-det/application-det.component';
import { CustomerComponent } from './user-dashboard/customer/customer.component';
import { LoanpaymentsComponent } from './user-dashboard/loanpayments/loanpayments.component';
import { PayEmiComponent } from './user-dashboard/pay-emi/pay-emi.component';
import { ViewEmisComponent } from './user-dashboard/view-emis/view-emis.component';
import { UserhomeComponent } from './userhome/userhome.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'ApplyForLoan', component: ApplyForLoanComponent },
  { path: 'emi', component: EMIComponent },
  { path: 'Register', component: RegisterComponent },
  { path: 'CustomerInfo', component: CustomerinfoComponent },
  { path: 'loginnew', component: LoginnewComponent },
  { path: 'form3', component: Form3Component },
  { path: 'form4', component: Form4Component },
  { path: 'form1', component: Form1Component },
  { path: 'form2', component: Form2Component },
  { path: 'finalapplication', component: FinalApplicationComponent },
  { path: 'checkeligibilty', component: CheckeligibilityComponent },
  { path: 'afternav', component: AfternavComponent },
  { path: 'customerDetails', component: CustomerComponent },
  { path: 'payEmi', component: PayEmiComponent },
  { path: 'application', component: ApplicationDetComponent },
  { path: 'loanPayView', component: LoanpaymentsComponent },
  { path: 'viewEmis', component: ViewEmisComponent },
  { path: 'Upload', component: FileUploadComponent },
  { path: 'adminlogin', component: AdminLoginComponent },
  { path: 'viewvehicle', component: ViewVehicleComponent },
  { path: 'entervehicle', component: EnterVehicleComponent },
  { path: 'enterloan', component: EnterLoanComponent },
  { path: 'viewloan', component: ViewLoanComponent },
  { path: 'viewCustomer', component: ViewCustomerComponent },
  { path: 'LoanPaymentDetails', component: LoanPayDetComponent },
  { path: 'Appapprove', component: ApplicationApprovalComponent },
  { path: 'emitrans', component: EmitransactionComponent },
  { path: 'adminhome', component: AdminhomeComponent },
  { path: 'userHome', component: UserhomeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
