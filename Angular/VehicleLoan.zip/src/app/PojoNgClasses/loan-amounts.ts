export class LoanAmounts {

    loanTypeId: number;
    interestRate: number;
    loanType: string;
    maxPriceRange: number;
    minPriceRange: number;
    minSalReqPa: number;
    processingFee: number;

    // constructor(loanTypeId: number, interestRate: number, loanType: string, maxPriceRange: number, minPriceRange: number,
    //     minSalReqPa: number, processingFee: number,) {

    //     this.loanTypeId = loanTypeId;
    //     this.interestRate = interestRate;
    //     this.loanType = loanType;
    //     this.maxPriceRange = maxPriceRange;
    //     this.minPriceRange = minPriceRange;
    //     this.minSalReqPa = minSalReqPa;
    //     this.processingFee = processingFee;
    // }

}
