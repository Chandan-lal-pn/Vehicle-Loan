export class Emi {

    emiId:number;
    emiNumber: number;
    transactionAmount: number;
    transactionDatetime:any;
    loanPaymentDetPg:any;
}
