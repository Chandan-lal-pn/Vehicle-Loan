import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insert-model',
  templateUrl: './insert-model.component.html',
  styleUrls: ['./insert-model.component.css']
})
export class InsertModelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
