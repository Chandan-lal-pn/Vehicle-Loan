import { Component, OnInit } from '@angular/core';
import { VehicleFormService } from '../vehicle-form.service';
import { Form3 } from './form3';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-form3',
  templateUrl: './form3.component.html',
  styleUrls: ['./form3.component.css']
})

export class Form3Component implements OnInit {
  vehicleType :string;
  selectVehicleCompany:string;
  selectVehicleModel :string;
  vehicledata = [];
  vehicleCompany =[];
  vehicleModel =[];
  userSelected : Form3;
  selectedXShowPrice :string;
  selectedOnRoadPrice :string;
  selectedDescription :string;
  selectedModelId :number;
  vehicleFound :boolean = false;

  constructor(private service:VehicleFormService, private route :Router) {
    
   }
  
  responseData :any []
  ngOnInit(): void {
    
  }
  getvehiclecompany(){
    this.service.getVehicleByType(this.vehicleType).subscribe(
      data => {
        this.vehicledata = data;
        console.log(this.vehicledata);
        this.vehicleFound = false;
        this.vehicleModel = [];
        this.vehicleCompany = [];
        this.getVehicleCompanyName();
      },
      error => console.log("Exception Occured")
    )
    
  }

  getVehicleCompanyName(){
    this.vehicleFound = false;
    this.vehicleCompany = [];
    this.vehicleModel = [];
    this.vehicledata.forEach(element => { console.log(element.vehicleCompanyName)
      this.vehicleCompany.push(element.vehicleCompanyName);
    });
    console.log(this.vehicleCompany)
    this.vehicleCompany = Array.from(new Set(this.vehicleCompany))
  }

  getVehicleModel(){
    this.vehicleFound = false;
    this.vehicleModel = [];
    this.vehicledata.forEach(element => { console.log(element.modelName)
      if(element.vehicleType == this.vehicleType && element.vehicleCompanyName == this.selectVehicleCompany){
      this.vehicleModel.push(element.modelName);
      }
    });
    console.log(this.vehicleModel)
     this.vehicleModel = Array.from(new Set(this.vehicleModel))
  }

  getInfo(){
    this.vehicledata.forEach(element => { console.log(element.onRoadPrice)
      console.log(element);
      console.log("Vehicle" + this.selectVehicleModel);
      if(element.modelName == this.selectVehicleModel){
      this.selectedXShowPrice = element.exShowroomPrice;
      this.selectedOnRoadPrice = element.onRoadPrice;
      this.selectedDescription = element.description;
      this.vehicleFound = true;
      this.selectedModelId = element.modelId;
      sessionStorage.setItem("vehicledata", JSON.stringify(element));
      console.log(this.selectedModelId);
      }
    });
  }
  getNextForm(){
    this.route.navigate(['/form4'])
  }

}
