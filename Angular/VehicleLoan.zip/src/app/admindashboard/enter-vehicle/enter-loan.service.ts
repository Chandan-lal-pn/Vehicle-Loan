import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Loan } from 'src/app/Loan';

@Injectable({
  providedIn: 'root'
})
export class EnterLoanService {
  getLoanList() {
    throw new Error('Method not implemented.');
  }

  constructor(private httpClient: HttpClient) { }

  baseUrl: string = "http://localhost:8088/loanAmt/";
  addLoan(loan: Loan) {
    return this.httpClient.post(this.baseUrl + "addLoanAmt", loan);
  }

}
