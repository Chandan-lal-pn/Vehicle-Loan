import { TestBed } from '@angular/core/testing';

import { EnterLoanService } from './enter-loan.service';

describe('EnterLoanService', () => {
  let service: EnterLoanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EnterLoanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
