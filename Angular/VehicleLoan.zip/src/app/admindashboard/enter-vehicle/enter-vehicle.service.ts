import { Injectable } from '@angular/core';
import { Vehicle } from 'src/app/PojoNgClasses/vehicle'; 
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class EnterVehicleService {
  constructor(private httpClient: HttpClient) { }
  baseUrl: string = "http://localhost:8088/vmod";
  addNewVehicle(vehicle: Vehicle):Observable<string> {
    return this.httpClient.post<string>(this.baseUrl + "/addCompany", vehicle);


  }
  public getVehicleList():Observable<any>{
    return this.httpClient.get<any>("http://localhost8086/vmod/getAllModels")
  }
}
