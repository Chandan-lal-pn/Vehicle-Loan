import { Component, OnInit } from '@angular/core';
import { LoanPayments } from 'src/app/PojoNgClasses/loan-payments';
import { LoanPayDetService } from './loan-pay-det.service';

@Component({
  selector: 'app-loan-pay-det',
  templateUrl: './loan-pay-det.component.html',
  styleUrls: ['./loan-pay-det.component.css']
})
export class LoanPayDetComponent implements OnInit {

  loanpd: LoanPayments[] = [];
  lpdet: any = [];
  constructor(private addloanService: LoanPayDetService) { }

  ngOnInit(): void {
    this.getloanpd();
  }

  public getloanpd() {
    console.log("reached");
    this.addloanService.getloanpd().subscribe(data => {
      this.loanpd = data;
      console.log("reached11");
      console.log(this.loanpd);
    },
      error => console.log("Exception Occured")
    );
  }

}
