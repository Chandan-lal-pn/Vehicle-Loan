import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmitransactionService {

  constructor(private http: HttpClient) { }
 
  public getEmiList(): Observable<any> {
    return this.http.get<any>("http://localhost:8088/emis/getAllEmis");
  }

  getEmiByLoanId(loanId: number){
    console.log('emi service load Id');
    return this.http.get<any>('http://localhost:8088/emis/getEmiByLoadId'+loanId);
  }
}
