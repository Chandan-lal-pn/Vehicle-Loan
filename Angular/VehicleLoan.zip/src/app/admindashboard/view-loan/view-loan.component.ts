import { Component, OnInit } from '@angular/core';
import { EnterLoanService } from '../enter-vehicle/enter-loan.service';
import { Loan } from 'src/app/Loan'; 
import { ViewLoanService } from './view-loan.service';

@Component({
  selector: 'app-view-loan',
  templateUrl: './view-loan.component.html',
  styleUrls: ['./view-loan.component.css']
})
export class ViewLoanComponent implements OnInit {
  loanList: any;
  loan: any;
  constructor(private addLoanService: ViewLoanService) { }

  ngOnInit(): void {
    this.getLoanList();






  }

  public getLoanList() {
    console.log("reached");
    this.addLoanService.getLoanList().subscribe(data => {
      this.loanList = data;
      console.log("reached11");
      console.log(this.loanList);
    },
      error => console.log("Exception Occured")
    );
  }

}



