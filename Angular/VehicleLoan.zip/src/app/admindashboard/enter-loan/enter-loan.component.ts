import { Component, OnInit } from '@angular/core';
import { EnterLoanService } from '../enter-vehicle/enter-loan.service';
import { Loan } from 'src/app/Loan';
import { Router } from '@angular/router';
import { LoanAmounts } from 'src/app/PojoNgClasses/loan-amounts';

@Component({
  selector: 'app-enter-loan',
  templateUrl: './enter-loan.component.html',
  styleUrls: ['./enter-loan.component.css'],
})
export class EnterLoanComponent implements OnInit {
  constructor(private beneservice: EnterLoanService, private route: Router) {
    
  }
  bene:LoanAmounts=new LoanAmounts();

  ngOnInit(): void {}
  formSubmit(LoanForm: any) {
    this.beneservice.addLoan(this.bene).subscribe((data) => {
      console.log('Return Value from Rest' + data);
    });
    (error) => {
      console.log(LoanForm.value);
      this.route.navigate(['/viewloan']);
    };
  }
}
