import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../PojoNgClasses/customer';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  baseURL: string = "http://localhost:8088/cust/"; //Spring's Employee JPA controller
  constructor(private myhttp: HttpClient) { }

  registerNewCustomer(customer: Customer): Observable<any> {
    console.log('reg service' + customer.firstName);
    return this.myhttp.post<any>(this.baseURL + "regisCust", customer);
  }
  // registerNewCustomer(customer: Customer): Observable<Customer> {
  //   console.log('reg service'+customer.firstName);
  //   return this.myhttp.post<Customer>(this.baseURL + '/regisCust/', +customer.firstName+ '/' + customer.lastName+ '/' +customer.emailId+ +customer.mobile+ '/' +customer.loginPassword);
  // }
}
