export class Register {
    age: number;
    dob: Date;
    emailId: string;
    employerName: string;
    existingEmisAmount: number;
    existingEmisCount: number;
    firstName: string;
    gender: string;
    lastName: string;
    loginPassword: string;
    mobile: string;
    nationality: string;
    pinCode: string;
    residenceAddress: string;
    residenceCity: string;
    residenceState: string;
    salaryPa: number;
    typeOfEmployment: string
}