export class FinalApp{     
      applicationId :number;
      applicationStatus:string;
      description: string;
      emiAmount:number;
      loanAmount: number;
      loanTenureMon:number;
      noOfEmis: number;
      vehicleChassisNo:string;
      witnessName:string;
}