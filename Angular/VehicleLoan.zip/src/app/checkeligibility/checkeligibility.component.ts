import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkeligibility',
  templateUrl: './checkeligibility.component.html',
  styleUrls: ['./checkeligibility.component.css']
})
export class CheckeligibilityComponent implements OnInit {
  age : number;
  salary :number;
  creditScore: number;
  loanAmount :number;
  employement :string;
  experience : number;
  msg =""
  isEligible = false;

  constructor() { }

  ngOnInit(): void {
  }

  getEligibility(){

    if (this.creditScore > 750 && this.age < 60) {
      if ((this.employement=="salaried") && (this.experience >= 1) && (this.age > 18)) {
        if((this.salary * 7) > this.loanAmount){
          this.isEligible = true;
          console.log("sucess")
        }else{
          console.log("failure")
          this.isEligible = false;
        }
      }
      else if ((this.employement=="selfEmployed") && (this.experience > 2) && (this.age > 21)) {
        if((this.salary * 4) > this.loanAmount){
          this.isEligible = true;
          console.log("sucess")
        }else{
          this.isEligible = false;
          console.log("failure")
        }
      }
      else{
        this.isEligible = false;
        console.log("failure")
      }
    }
    

    if(this.isEligible){
      this.msg="Congratulation!! You are eligible"
    }
    else{
      this.msg="Sorry :( You are not eligible"
    }
    console.log(this.msg);
  }

}
