import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Form3 } from './form3/form3';

@Injectable({
  providedIn: 'root'
})
export class VehicleFormService {

  constructor( private http : HttpClient) { }

  // public getVehicleByType(type :string):Observable<any>{
  //   return this.http.post<any>("http://localhost:8088/vmod/getByVehicleType/",type);
  // }
  public getVehicleByType(type :string):Observable<any>{
    return this.http.get<any>("http://localhost:8088/vmod/getByVehicleType/" + type);
  }
}
