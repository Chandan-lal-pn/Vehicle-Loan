import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CustomerInfo } from './CustomerInfo';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http : HttpClient) { }

  public logInUserFromRemote(custInfo : CustomerInfo):Observable<any>{
    return this.http.post<any>("http://localhost:8088/cust/loginCust", custInfo);
  }
}
