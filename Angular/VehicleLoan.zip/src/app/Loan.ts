export class Loan {
    interestRate: number = 0;
    loanType: string = "";
    maxPriceRange: number = 0;
    minPriceRange: number = 0;
    minSalReqPa: number = 0;
    processingFee: number = 0;
}