import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerInfo } from '../CustomerInfo';
import { CustomerService } from '../user-dashboard/customer.service';

@Component({
  selector: 'app-form2',
  templateUrl: './form2.component.html',
  styleUrls: ['./form2.component.css']
})
export class Form2Component implements OnInit {
  newCustomer:CustomerInfo = JSON.parse(sessionStorage.getItem("userdata"));
  vehicleData:any = JSON.parse(sessionStorage.getItem("vehicledata"));
  constructor(private route :Router, private custServe: CustomerService) { }

  ngOnInit(): void {
    console.log("form2")
  }

  getNextForm(){
    sessionStorage.setItem("userdata", JSON.stringify(this.newCustomer));
    this.custServe.updateCustDet(this.newCustomer).subscribe(
      data=>console.log('customer edited'),
      error=> console.log('error occured')
    );
    this.route.navigate(['/finalapplication']);
    console.log("Personal Info");
    console.log(this.newCustomer);
    
    console.log("Vehicle Info");
    console.log(this.vehicleData);

    console.log("Loan Info");
    console.log(this.newCustomer);

  }

}
