import { variable } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { CustomerInfo } from '../CustomerInfo';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  firstName :any = localStorage.getItem("userInfo");
  //userdata :any = JSON.parse(localStorage.getItem("userdata"));
  
  constructor() { }

  ngOnInit(): void {
  }

  
}

