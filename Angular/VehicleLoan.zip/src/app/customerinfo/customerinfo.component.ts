import { Component, OnInit } from '@angular/core';
import { CustomerInfo } from '../CustomerInfo';
import { CustomerInfoService } from '../customerinfo.service';
import { Register } from '../Register';

@Component({
  selector: 'app-customerinfo',
  templateUrl: './customerinfo.component.html',
  styleUrls: ['./customerinfo.component.css']
})
export class CustomerinfoComponent implements OnInit {
bene: Register;
  constructor(private beneservice: CustomerInfoService) {
    this.bene=new CustomerInfo;
   }

  ngOnInit(): void {
    
  }
  formSubmit(CustomerDetailForm:any){
    alert("It worked")  
    this.beneservice.addNewUser(this.bene).subscribe((data)=>{
      console.log("Return Value from REST"+data);
      }
      )
      console.log(CustomerDetailForm.value)
  }
}
