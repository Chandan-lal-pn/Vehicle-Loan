import { Component, OnInit } from '@angular/core';
import { CustomerInfo } from '../CustomerInfo';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  
  newCustomer: any = JSON.parse(sessionStorage.getItem("userdata"));
  isLogin = false;
  isLogOut = false;
  constructor() { 
    
  }

  ngOnInit(): void {
   console.log(this.newCustomer)
   if(this.newCustomer != null){
    console.log("Login")
    this.isLogin = true;
    // this.isLogout = true;
   }
   else{
    console.log("not login")
    this.isLogin = false;
   }
    }
    
 

}
