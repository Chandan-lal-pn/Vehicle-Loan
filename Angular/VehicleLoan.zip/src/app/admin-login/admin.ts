export class Admin {
    adminId: number;
    adminPassword:string;
    adminUserid:string;
    adminUsername:string;
  }
  