import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FinalApp } from './final-application/finalApp';

@Injectable({
  providedIn: 'root'
})
export class FinalappService {

  constructor(private http : HttpClient) { }

  public setApplication(custId:number,modelId:number, loanId:number,finalApp:FinalApp):Observable<any>{
    return this.http.post<any>("http://localhost:8088/app/createNewApp/"+ custId +"/" + modelId+ "/" + loanId + "/", finalApp )
  }
}
