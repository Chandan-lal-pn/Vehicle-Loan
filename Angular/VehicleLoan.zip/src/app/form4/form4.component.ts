import { Component, OnInit } from '@angular/core';
import { LoanFormService } from '../loan-form.service';
import { NgModel } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-form4',
  templateUrl: './form4.component.html',
  styleUrls: ['./form4.component.css']
})
export class Form4Component implements OnInit {
  loanAmount :any;
  constructor(private service:LoanFormService, private route :Router) { }
  loanDetails : any 
  isVisible = false;
  msg :string;
  ngOnInit(): void {
  }
  
  getLoanByAmount(){
    this.loanDetails = []
    this.isVisible = false;
    console.log(this.loanAmount);
    this.service.getLoanByAmount(this.loanAmount).subscribe(
      data => {
        this.loanDetails = data;
        console.log(this.loanDetails[0].loanType);
        if (this.loanDetails.length > 0) {
          this.msg ='';
          this.isVisible = true;
        }
        else{
          this.isVisible = false;
          this.msg="No record Found";
        }
      },
      error => { 
      console.log("Exception Occurs");
      this.msg="Invalid input Enter numbers";
    })
    
  }
  getNextForm(){
    sessionStorage.setItem("loanAmount", this.loanAmount.toString());
    sessionStorage.setItem("loanData", JSON.stringify(this.loanDetails[0]));
    this.route.navigate(['/form1'])
  }
  

}
