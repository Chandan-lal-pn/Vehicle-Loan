import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';

import { ApplyForLoanComponent } from './apply-for-loan/apply-for-loan.component';
import { RegisterComponent } from './register/register.component';

import { FooterComponent } from './footer/footer.component';
import { Ng5SliderModule } from 'ng5-slider';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EMIComponent } from './emi/emi.component';
import { HttpClientModule } from '@angular/common/http';
import { CustomerinfoComponent } from './customerinfo/customerinfo.component';
import { LoginnewComponent } from './loginnew/loginnew.component';
import { Form3Component } from './form3/form3.component';
import { Form4Component } from './form4/form4.component';
import { Form1Component } from './form1/form1.component';
import { Form2Component } from './form2/form2.component';
import { FinalApplicationComponent } from './final-application/final-application.component';
import { CheckeligibilityComponent } from './checkeligibility/checkeligibility.component';
import { AfternavComponent } from './afternav/afternav.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { ViewEmisComponent } from './user-dashboard/view-emis/view-emis.component';
import { LoanpaymentsComponent } from './user-dashboard/loanpayments/loanpayments.component';
import { ApplicationDetComponent } from './user-dashboard/application-det/application-det.component';
import { CustomerComponent } from './user-dashboard/customer/customer.component';
import { PayEmiComponent } from './user-dashboard/pay-emi/pay-emi.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { ApplicationApprovalComponent } from './admindashboard/application-approval/application-approval.component';
import { EmitransactionComponent } from './admindashboard/emitransaction/emitransaction.component';
import { EnterLoanComponent } from './admindashboard/enter-loan/enter-loan.component';
import { EnterVehicleComponent } from './admindashboard/enter-vehicle/enter-vehicle.component';
import { LoanPayDetComponent } from './admindashboard/loan-pay-det/loan-pay-det.component';
import { ViewCustomerComponent } from './admindashboard/view-customer/view-customer.component';
import { ViewLoanComponent } from './admindashboard/view-loan/view-loan.component';
import { ViewVehicleComponent } from './admindashboard/view-vehicle/view-vehicle.component';
import { AdminhomeComponent } from './admindashboard/adminhome/adminhome.component';



@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    ApplyForLoanComponent,
    RegisterComponent,
    FooterComponent,
    EMIComponent,
    CustomerinfoComponent,
    LoginnewComponent,
    Form3Component,
    Form4Component,
    Form1Component,
    Form2Component,
    FinalApplicationComponent,
    CheckeligibilityComponent,
    AfternavComponent,
    FileUploadComponent,
    ViewEmisComponent,
    LoanpaymentsComponent,
    ApplicationDetComponent,
    CustomerComponent,
    PayEmiComponent,
    UserhomeComponent,
    AdminLoginComponent,
    ApplicationApprovalComponent,
    EmitransactionComponent,
    EnterLoanComponent,
    EnterVehicleComponent,
    LoanPayDetComponent,
    ViewCustomerComponent,
    ViewLoanComponent,
    ViewVehicleComponent,
    AdminhomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Ng5SliderModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
