import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApplicationsService {

  baseUrl: string = "http://localhost:8088/app/"
  constructor(private myhttp: HttpClient) { }
  getAllApp():Observable<any>{
    console.log('application service');
    return this.myhttp.get<any>(this.baseUrl+"getAllApp")
  }

  getAppByCustId(custId:number):Observable<any>{
    console.log('application service');
    return this.myhttp.get<any>(this.baseUrl+"getAppById/"+custId);
  }

  updateApplication(appId:number,status:string):Observable<any>{
    console.log('application service');
    return this.myhttp.post<any>(this.baseUrl+'updateAppStatus/'+appId+'/'+ status,null);
  }
}
