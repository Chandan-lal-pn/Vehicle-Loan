import { Component, OnInit } from '@angular/core';
import { Emi } from 'src/app/PojoNgClasses/emi'; 
import { EmiService } from 'src/app/services/emi-service.service';

@Component({
  selector: 'app-view-emis',
  templateUrl: './view-emis.component.html',
  styleUrls: ['./view-emis.component.css']
})
export class ViewEmisComponent implements OnInit {

  constructor(private emiServe: EmiService) { }
  emiList: Emi[] = []
  loanPaymentId: number = JSON.parse(sessionStorage.getItem("loanID"));
  ngOnInit(): void {
    this.emiServe.getEmiByLoanId(this.loanPaymentId).subscribe(
      data => {
        console.log('data received emi');
        this.emiList = data;
        console.log(this.emiList[0].transactionAmount)
      },
      error => console.log("error1234")
    )
  }


}