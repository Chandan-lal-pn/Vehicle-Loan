import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../PojoNgClasses/customer';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  public logInUserFromRemote(custInfo: Customer): Observable<any> {
    console.log(JSON.stringify(custInfo));
    return this.http.post<any>("http://localhost:8086/cust/loginCust", custInfo);
  }
}
