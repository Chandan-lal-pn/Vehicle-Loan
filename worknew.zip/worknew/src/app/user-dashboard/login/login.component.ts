import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/PojoNgClasses/customer';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  newCust: Customer=new Customer();
  msg: string;
  constructor(private loginServe: LoginService, private route:Router) { }


  ngOnInit(): void {
  }

  getCustInfo(){
    this.loginServe.logInUserFromRemote(this.newCust).subscribe(
      data => {
        console.log("Responce received");
        console.log("Hello" + this.newCust.firstName)
        this.newCust = data;
        console.log(this.newCust);
        localStorage.setItem("userdata", JSON.stringify(this.newCust));
        localStorage.setItem("userName", this.newCust.firstName);
        this.route.navigate(['/application'])
      },
      error => {
        console.log("Exception Occured");
        this.msg ="Bad Credentials, please enter valid mobile number and password"
      }

    )
    
  }

}
