import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/PojoNgClasses/customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  newCust:Customer = JSON.parse(sessionStorage.getItem("userdata"));
  CustomerList:any=[];    
  constructor(private service: CustomerService) { }


  ngOnInit(): void {
    console.log(this.newCust)
    this.getCust();
    }

  public getCust(){
    this.service.getCustomerList(this.newCust.custId).subscribe(
      data=>{
    console.log("sss");
this.CustomerList=data;
  },
    error=>console.log("eeee")

  )
}

}
