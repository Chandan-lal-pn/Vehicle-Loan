import { Component, OnInit } from '@angular/core';
import { Applications } from 'src/app/PojoNgClasses/applications';
import { Customer } from 'src/app/PojoNgClasses/customer';
import { ApplicationsService } from '../applications.service';

@Component({
  selector: 'app-application-det',
  templateUrl: './application-det.component.html',
  styleUrls: ['./application-det.component.css']
})
export class ApplicationDetComponent implements OnInit {

  newCust:Customer = JSON.parse(sessionStorage.getItem("userdata"));
  applicationList: Applications[]
  constructor(private appServe: ApplicationsService) { }

  ngOnInit(): void {
    console.log(this.newCust);
    this.appServe.getAppByCustId(this.newCust.custId).subscribe(
      data=>{
        console.log('success');
        this.applicationList = data;
      },
      (error)=>console.log("eeee")
    )
  }
  
  

}
