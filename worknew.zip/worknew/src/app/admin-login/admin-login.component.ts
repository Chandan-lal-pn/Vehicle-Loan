import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from './admin';
import { AdminService } from './admin.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  admin:Admin=new Admin();
  constructor(private adminServe:AdminService, private route:Router) { }

  ngOnInit(): void {
  }

  verifyAdmin(){
    console.log('verifyAdmin in component');
    this.adminServe.loginAdmin(this.admin).subscribe(
      data=>{
        console.log('admin logged in data'+JSON.stringify(data));
        this.admin=data;
        this.route.navigate(['/adminhome']);
      },
      error=> console.log('could not login admin with this data')
    );

  }
}
