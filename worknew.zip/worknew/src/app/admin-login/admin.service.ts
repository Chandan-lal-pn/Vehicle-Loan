import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private myhttp: HttpClient) { }

  baseUrl: string = "http://localhost:8088/admin/"

  loginAdmin(admin:Admin):Observable<any>{
    console.log('admin login service verify'+ admin);
    return this.myhttp.post<any>(this.baseUrl+'logInAdm',admin);
  }
  
}
