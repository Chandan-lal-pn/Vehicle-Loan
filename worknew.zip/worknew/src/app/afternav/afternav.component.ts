import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-afternav',
  templateUrl: './afternav.component.html',
  styleUrls: ['./afternav.component.css']
})
export class AfternavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  logOut(){
    localStorage.clear();
  }
}
