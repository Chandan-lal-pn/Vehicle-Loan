import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AfternavComponent } from './afternav.component';

describe('AfternavComponent', () => {
  let component: AfternavComponent;
  let fixture: ComponentFixture<AfternavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AfternavComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AfternavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
