import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { Emi } from './PojoNgClasses/emi';

@Injectable({
  providedIn: 'root'
})
export class EmiService {

  baseURL: string = "http://localhost:8088/emis/";
  constructor(private myhttp: HttpClient) { }

  emiPay(newEmi: Emi, loanPaymentId: number): Observable<string> {

    console.log('emi serve', +newEmi.transactionAmount);
    return this.myhttp.post<string>(this.baseURL + 'createTransaction/' + loanPaymentId + '/', newEmi);
  }

  getEmiByLoanId(loanId: number): Observable<any> {
    console.log('emi serve', +loanId);
    return this.myhttp.get<any>(this.baseURL + "getEmiByEmiId/" + loanId);
  }

}
