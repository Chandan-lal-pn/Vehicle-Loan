import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerInfo } from '../CustomerInfo';
import { FinalappService } from '../finalapp.service';
import { FinalApp} from './finalApp';

@Component({
  selector: 'app-final-application',
  templateUrl: './final-application.component.html',
  styleUrls: ['./final-application.component.css']
})
export class FinalApplicationComponent implements OnInit {
  customerData:CustomerInfo = JSON.parse(sessionStorage.getItem("userdata"));
  vehicleData:any = JSON.parse(sessionStorage.getItem("vehicledata"));
  loanData:any = JSON.parse(sessionStorage.getItem("loanData"));
  loanAmount = sessionStorage.getItem("loanAmount")
  finalApp :FinalApp = new FinalApp();
  rate : number;

  constructor(private service:FinalappService, private route :Router) { }

  ngOnInit(): void {
    console.log(this.loanAmount)
    console.log(this.loanData.loanTypeId);
    console.log(this.vehicleData.modelId);
    console.log(this.customerData.custId);
    this.finalApp.applicationStatus = "pending";
    this.finalApp.loanAmount = Number(this.loanAmount);
     }
  onEdit(){
    if (isNaN(this.finalApp.emiAmount)) this.finalApp.emiAmount = 0;
    // console.log("Hii " + this.finalApp.emiAmount);
    // console.log("Hii " + this.loanData.interestRate);
    // console.log("Hii " + this.finalApp.loanAmount);
    // console.log("Hii " + this.loanData.loanTenureMon);
    this.loanData.loanTenureMon = Number(this.loanData.loanTenureMon);
    
    // this.finalApp.emiAmount = ((this.finalApp.loanAmount * this.loanData.interestRate) * ((1+this.loanData.interestRate) ** this.loanData.loanTenureMon))
    //  / (((1+this.loanData.interestRate)**this.loanData.loanTenureMon) -1 );
  }
  setApplication(){
    console.log(this.finalApp);
     this.finalApp.noOfEmis =this.finalApp.loanTenureMon;
    this.service.setApplication(this.customerData.custId,this.vehicleData.modelId,this.loanData.loanTypeId,this.finalApp).subscribe(
      data => {
        console.log(data);
        console.log("success");
      },
      error =>{
        console.log("Error");
      }
    )
    this.route.navigate(['/afternav']);
  }

}
