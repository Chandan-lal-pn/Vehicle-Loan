import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { Validators } from '@angular/forms';
import { Register } from '../Register';
import { RegisterService } from './register.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  bene: Register;
  constructor(private beneservice:RegisterService)
{
  this.bene=new Register();
}
  ngOnInit(): void {
    
  }
  formSubmit(UserForm:any){
    this.beneservice.addNewUser(this.bene).subscribe((data)=>{
    console.log("Return Value from REST"+data);
    }
    )
    console.log(UserForm.value)
  }
}















