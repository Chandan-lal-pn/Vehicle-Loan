import { Component, OnInit } from '@angular/core';

import { ViewCustomerService } from './view-customer.service'; 

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {
  CustomerList: any;
  customer: any;
  constructor(private CustomerService: ViewCustomerService) { }

  ngOnInit(): void {
    this.getCustomerList();
  }
  public getCustomerList() {
    console.log("reached");
    this.CustomerService.getCustomerList().subscribe(data => {
      this.CustomerList = data;
      console.log("reached11");

      console.log(this.CustomerList);
    },
      error => console.log("exception Occured")
    );


  }
}
