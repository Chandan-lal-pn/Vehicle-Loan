import { Component, OnInit } from '@angular/core';

import { EmitransactionService } from './emitransaction.service'; 

@Component({
  selector: 'app-emitransaction',
  templateUrl: './emitransaction.component.html',
  styleUrls: ['./emitransaction.component.css']
})
export class EmitransactionComponent implements OnInit {


  emiList: any = [];
  emi: any;
  constructor(private addEmiService: EmitransactionService) { }
  ngOnInit(): void {

    this.getEmiList();
  }

  public getEmiList() {
    console.log("reached");
    this.addEmiService.getEmiList().subscribe(data => {
      this.emiList = data;
      console.log("reached11");

    },
      error => console.log("Exception Occured")
    );

  }
}
