export class Emi {
    transactionDatetime: any;
    transactionAmount: number = 0;
    loanPaymentDetPg: any;
    emiNumber: number = 0;
    emiId: number = 0;
}