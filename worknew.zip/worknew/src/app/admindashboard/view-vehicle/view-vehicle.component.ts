
import { Component, OnInit } from '@angular/core';


import { ViewVehicleService } from './view-vehicle.service'; 

@Component({
  selector: 'app-view-vehicle',
  templateUrl: './view-vehicle.component.html',
  styleUrls: ['./view-vehicle.component.css']
})
export class ViewVehicleComponent implements OnInit {
  VehicleList: any;
  vehicle: any;
  constructor(private viewVehicleService: ViewVehicleService) { }


  ngOnInit(): void {
    this.getVehicleList();
  }


  public getVehicleList() {
    console.log("reached");
    this.viewVehicleService.getVehicleList().subscribe(data => {
      this.VehicleList = data;
      console.log("reached11");
      console.log(this.VehicleList);
    },
      error => console.log("Exception Occured")
    );
  }
}