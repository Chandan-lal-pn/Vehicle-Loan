import { Component, OnInit } from '@angular/core';
import { EnterLoanService } from '../enter-vehicle/enter-loan.service';
import { Loan } from 'src/app/Loan';

@Component({
  selector: 'app-enter-loan',
  templateUrl: './enter-loan.component.html',
  styleUrls: ['./enter-loan.component.css']
})
export class EnterLoanComponent implements OnInit {
  bene: Loan;
  constructor(private beneservice: EnterLoanService) {
    this.bene = new Loan();
  }

  ngOnInit(): void {
  }
  formSubmit(LoanForm: any) {
    alert("It worked")
    this.beneservice.addLoan(this.bene).subscribe((data) => {
      console.log("Return Value from Rest" + data);
    })
    console.log(LoanForm.value)
  }

}
