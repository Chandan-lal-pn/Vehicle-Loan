import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnterLoanComponent } from './enter-loan.component';

describe('EnterLoanComponent', () => {
  let component: EnterLoanComponent;
  let fixture: ComponentFixture<EnterLoanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnterLoanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
