import { Component, OnInit } from '@angular/core';
import { Applications } from 'src/app/PojoNgClasses/applications'; 
import { LoanPayServiceService } from 'src/app/services/loan-pay-service.service'; 
import { ApplicationsService } from './applications.service';

@Component({
  selector: 'app-application-approval',
  templateUrl: './application-approval.component.html',
  styleUrls: ['./application-approval.component.css']
})
export class ApplicationApprovalComponent implements OnInit {

  constructor(private appServe: ApplicationsService, private loanPayServe:LoanPayServiceService) { }
  applicationList: Applications[]=[];
  custId: number;
  approve:string;
  reject:string;
  adminId:number=JSON.parse(localStorage.getItem("adminObject")); //convert to  adminId
  ngOnInit(): void {
    this.appServe.getAllApp().subscribe(
      data=>{
        console.log('application recieved');
        this.applicationList=data;
      }
    )

  }

  
  getAppByCustId(){
    this.appServe.getAppByCustId(this.custId).subscribe(
      data=>{
        console.log('success');
        this.applicationList = data;
      },
      (error)=>console.log("eeee")
    )
  }

  declineRequest(appId:number){
    this.reject='Rejected';
    this.appServe.updateApplication(appId,this.reject).subscribe(
      data=>{
        console.log('application updated'+data);
        console.log('new loan entry being generated');
         // replace 1 with adminId
      },
      error=> console.log('error occured in updating application')
    )
  }
  

  approveRequest(appId:number){
    this.approve='Approved';
    this.appServe.updateApplication(appId,this.approve).subscribe(
      data=>{
        console.log('application updated'+data);
        console.log('new loan entry being generated');
        this.loanPayServe.newLoanEntry(appId,1).subscribe(
          data=> console.log('new loan entry generated'),
          error=> console.log('error')
        ) // replace 1 with adminId
      },
      error=> console.log('error occured in updating application')
    )
  }

}
