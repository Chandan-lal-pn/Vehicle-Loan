import { Component, OnInit } from '@angular/core';
import { EnterVehicleService } from './enter-vehicle.service';
import { Vehicle } from 'src/app/PojoNgClasses/vehicle'; 

@Component({
  selector: 'app-enter-vehicle',
  templateUrl: './enter-vehicle.component.html',
  styleUrls: ['./enter-vehicle.component.css']
})
export class EnterVehicleComponent implements OnInit {
  bene: Vehicle;

  constructor(private beneservice: EnterVehicleService) {

    this.bene=new Vehicle();
   }

  ngOnInit(): void {
  }
  formSubmit(VehicleForm:any){
    alert("it WOrked")
    this.beneservice.addNewVehicle(this.bene).subscribe((data)=>{
      console.log("Return Value from Rest"+ data);
    })
    console.log(VehicleForm.value)
  }
}
