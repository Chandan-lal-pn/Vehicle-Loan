export class Applications {
  applicationId: number;
  applicationStatus: string;
  emiAmount: string;
  noOfEmis: number;
  loanAmount: number;
  loanTenureMon: number;
  vehicleChassisNo: string;
  witnessName: string;
  custBasicDetailsPg: any;
  loanAmountsPg: any;
  vehicleModelPg: any;
}
