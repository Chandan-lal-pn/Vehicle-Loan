export class Vehicle {

    modelId :number;
	description : string;
	exShowroomPrice :number;
	modelName :string;
	onRoadPrice :number;
	vehicleCompanyName :string;
	vehicleType :string;

	
    // constructor(modelId :number, description : string, exShowroomPrice :number,modelName :string,
	// 	onRoadPrice :number,vehicleCompanyName :string, vehicleType :string){ 
	// 		this.modelId = modelId;
	// 		this.description = description;
	// 		this.exShowroomPrice = exShowroomPrice;
	// 		this.modelName = modelName;
	// 		this.onRoadPrice = onRoadPrice;
	// 		this.vehicleCompanyName = vehicleCompanyName;
	// 		this.vehicleType = vehicleType;   
    // }
}
