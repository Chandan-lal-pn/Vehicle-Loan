import { Admin } from "../admin-login/admin";

export class LoanPayments {
  loanPaymentId: number;
  approvalDate: Date;
  emisFilled: number;
  emisLeft: number;
  amountDone: number;
  amountLeft: number;
  nextDue: Date;
  adminDetail: Admin;
  applicationDetPg: any;
}
